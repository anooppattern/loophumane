
'use client';
import { useEffect, useState } from 'react';

const items = [
  { title: 'Retail vision: 9500+ SKUs', blurb: 'Improved on-shelf recognition with precise labels and fast spec iteration.' },
  { title: 'LLM RLHF at scale', blurb: 'Millions of pairwise rankings with rubric-guided review to train reward models.' },
  { title: 'Safety red-team', blurb: 'Continuous adversarial testing reduced jailbreak success by 43% QoQ.' },
];

export default function CaseStudiesPage() {
  const [i, setI] = useState(0);
  useEffect(()=>{ const id = setInterval(()=> setI((x)=> (x+1)%items.length), 3800); return ()=> clearInterval(id); }, []);
  return (
    <main className="min-h-screen bg-neutral-950 text-white">
      <section className="mx-auto max-w-5xl px-4 py-16">
        <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight">Case studies</h1>
        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((it, idx)=> (
            <div key={it.title} className={`rounded-2xl border p-6 ${i===idx?'border-white/20 bg-neutral-900':'border-white/10 bg-neutral-900/40'}`}>
              <div className="font-medium">{it.title}</div>
              <p className="mt-2 text-sm text-neutral-300">{it.blurb}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
